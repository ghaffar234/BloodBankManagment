/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PackageClasses;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp
 */
public class DonorDirectory {
    
    public static ArrayList<Donor> donors = new ArrayList<>();
    
    
    public static void addDonor(Donor obj){        
        donors.add(obj);
        
        //JOptionPane.showMessageDialog(null, "Donor data is saved successfully");
    }
    public static ArrayList<Donor> searchDonor(String location){
        ArrayList<Donor>selectiveDonor = new ArrayList();
        for (int i = 0; i < donors.size(); i++) {
            if (donors.get(i).getLocation().equalsIgnoreCase(location)) {
                selectiveDonor.add(donors.get(i));
                System.out.println(donors.get(i).getLocation());
            }
        }
        return selectiveDonor;
    }
    public static int getUnitCount(String bloodGroup){
        int count = 0;
        for (int i = 0; i < donors.size(); i++) {
            if (donors.get(i).getBloodGroup().equalsIgnoreCase(bloodGroup)) {
                    count++;
            }
        }
        return count;
    }
    
    public static ArrayList<Donor> getDonorList(){
        ArrayList<Donor>selectiveDonor = new ArrayList();
        for (int i = 0; i < donors.size(); i++) {
            //if (donors.get(i).getLocation().equalsIgnoreCase(location)) {
                selectiveDonor.add(donors.get(i));
                //System.out.println(donors.get(i).getLocation());
            //}
        }
        return selectiveDonor;
    }
    
    public static Donor searchById(String id){
        for (int i = 0; i < donors.size(); i++) {
            if (donors.get(i).getDonorId().equalsIgnoreCase(id)) {
                return donors.get(i);
            }
        }
        JOptionPane.showMessageDialog(null, "Donor not found");
        return null;
    }
    public static void updateDonor(Donor obj, String id) {
        for (int i = 0; i < donors.size(); i++) {
            if (donors.get(i).getDonorId().equalsIgnoreCase(id)) {
                donors.get(i).setDonorId(obj.getDonorId());
                donors.get(i).setFullName(obj.getFullName());
                donors.get(i).setFatherName(obj.getFatherName());
                donors.get(i).setMotherName(obj.getMotherName());
                donors.get(i).setMobileNumber(obj.getMobileNumber());
                donors.get(i).setDateOfBirth(obj.getDateOfBirth());
                donors.get(i).setGender(obj.getGender());
                donors.get(i).setEmail(obj.getEmail());
                donors.get(i).setBloodGroup(obj.getBloodGroup());
                donors.get(i).setCity(obj.getCity());
                donors.get(i).setCompleteAddress(obj.getCompleteAddress());
                JOptionPane.showMessageDialog(null, "Donor is updated now");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Donor not found");
    }  
    public static ArrayList<Donor> searchDonorByBlood(String BloodGroup) {
    ArrayList<Donor> matchingDonors = new ArrayList<>();
    for (Donor donor : donors) {
        if (donor.getBloodGroup().equalsIgnoreCase(BloodGroup)) {
            matchingDonors.add(donor);
        }
    }
    return matchingDonors;
}
    public static void deleteDonor(String id) {
    for (int i = 0; i < donors.size(); i++) {
        if (donors.get(i).getDonorId().equalsIgnoreCase(id)) {
            donors.remove(i);
            JOptionPane.showMessageDialog(null, "Donor has been deleted.");
            return;
        }
    }
    JOptionPane.showMessageDialog(null, "Donor not found.");
}
    
    public void saveToFile(String filename) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            File file=new File("data txt");
        file.createNewFile();
            out.writeObject(donors);
            JOptionPane.showMessageDialog(null, "Data saved successfully!");
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    // Load Donors from file
    public void loadFromFile(String filename) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            donors = (ArrayList<Donor>) in.readObject();
            JOptionPane.showMessageDialog(null, "Data loaded successfully!");
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }
}

